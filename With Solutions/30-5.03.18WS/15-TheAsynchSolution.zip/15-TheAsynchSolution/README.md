* **Instructions**

* Work in pairs to see if you can come up with the reason why our code in `18-TheAsynchProblem` is console.logging "undefined" despite no errors being recorded.

* See if you can come up with a possible solution to this problem.

  * You are free to search the web for potential causes/solutions to this issue, as it is a problem that many new coders have faced and that they will continue to face for years and years to come.

  * Use the code contained within `18-TheAsynchProblem` to run, test, and mess with on your own.
  
